package vn.NguyenTrongTri_63132732;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class activityBai4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai4);
    }
}